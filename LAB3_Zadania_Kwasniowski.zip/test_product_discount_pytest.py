# -*- coding: utf-8 -*-
"""Testy pytest dla apply_discount."""

import pytest
from product import Product


@pytest.fixture
def product():
    return Product("Mysz", 100.0, 10)


@pytest.mark.parametrize("percent, expected_price", [
    (0, 100.0),
    (50, 50.0),
    (100, 0.0),
])
def test_apply_discount(product, percent, expected_price):
    product.apply_discount(percent)
    assert product.price == expected_price


@pytest.mark.parametrize("percent", [-1, -20, 101, 150])
def test_apply_discount_invalid_percent_raises(product, percent):
    with pytest.raises(ValueError):
        product.apply_discount(percent)
