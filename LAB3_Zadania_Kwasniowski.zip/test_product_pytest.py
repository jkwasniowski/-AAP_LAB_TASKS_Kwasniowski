# -*- coding: utf-8 -*-
"""Testy pytest dla klasy Product."""

import pytest
from product import Product


@pytest.fixture
def product():
    """Tworzy instancje Product do testow."""
    return Product("Laptop", 3000.0, 10)


def test_is_available(product):
    """Sprawdz dostepnosc produktu."""
    assert product.is_available() is True


def test_total_value(product):
    """Sprawdz wartosc calkowita."""
    assert product.total_value() == 30000.0


@pytest.mark.parametrize("amount, expected_quantity", [
    (5, 15),
    (0, 10),
    (100, 110),
])
def test_add_stock_parametrized(product, amount, expected_quantity):
    """Testuje add_stock z roznymi wartosciami."""
    product.add_stock(amount)
    assert product.quantity == expected_quantity


@pytest.mark.parametrize("amount, expected_quantity", [
    (1, 9),
    (5, 5),
    (10, 0),
])
def test_remove_stock_parametrized(product, amount, expected_quantity):
    """Testuje remove_stock z roznymi wartosciami."""
    product.remove_stock(amount)
    assert product.quantity == expected_quantity


def test_remove_stock_too_much_raises(product):
    """Sprawdz, czy proba usuniecia za duzej ilosci rzuca ValueError."""
    with pytest.raises(ValueError):
        product.remove_stock(11)


def test_add_stock_negative_raises(product):
    """Sprawdz, czy ujemna wartosc w add_stock rzuca ValueError."""
    with pytest.raises(ValueError):
        product.add_stock(-1)


def test_remove_stock_negative_raises(product):
    """Sprawdz, czy ujemna wartosc w remove_stock rzuca ValueError."""
    with pytest.raises(ValueError):
        product.remove_stock(-1)


def test_negative_price_raises():
    """Sprawdz, czy ujemna cena rzuca ValueError."""
    with pytest.raises(ValueError):
        Product("Tablet", -100.0, 5)


def test_negative_quantity_raises():
    """Sprawdz, czy ujemna ilosc rzuca ValueError."""
    with pytest.raises(ValueError):
        Product("Tablet", 100.0, -5)
