# -*- coding: utf-8 -*-
"""Klasa Product."""


class Product:
    """Reprezentuje produkt w sklepie internetowym."""

    def __init__(self, name: str, price: float, quantity: int):
        if price < 0:
            raise ValueError("Cena nie moze byc ujemna")
        if quantity < 0:
            raise ValueError("Ilosc nie moze byc ujemna")

        self.name = name
        self.price = price
        self.quantity = quantity

    def add_stock(self, amount: int):
        """Dodaje okreslona ilosc produktow do magazynu."""
        if amount < 0:
            raise ValueError("Nie mozna dodac ujemnej ilosci")

        self.quantity += amount

    def remove_stock(self, amount: int):
        """Usuwa okreslona ilosc produktow z magazynu."""
        if amount < 0:
            raise ValueError("Nie mozna usunac ujemnej ilosci")
        if amount > self.quantity:
            raise ValueError("Za mala ilosc w magazynie")

        self.quantity -= amount

    def is_available(self) -> bool:
        """Zwraca True, jezeli produkt jest dostepny."""
        return self.quantity > 0

    def total_value(self) -> float:
        """Zwraca calkowita wartosc produktow w magazynie."""
        return self.price * self.quantity

    def apply_discount(self, percent: float):
        """Obniza cene o podany procent z zakresu 0-100."""
        if percent < 0 or percent > 100:
            raise ValueError("Rabat musi byc w zakresie 0-100")

        self.price = self.price * (1 - percent / 100)
